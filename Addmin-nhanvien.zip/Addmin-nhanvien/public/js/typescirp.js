
function validateForm() {
    if($('#form-login')[0].checkValidity() === false){
        event.preventDefault();
        event.stopPropagation();
    }
    $('#form-login').addClass('was-validated');
}